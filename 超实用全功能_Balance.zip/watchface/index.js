﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_stand_current_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_uvi_text_text_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 27,
              hour_startY: 184,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: '15.png',
              hour_unit_tc: '15.png',
              hour_unit_en: '15.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 143,
              minute_startY: 184,
              minute_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 241,
              second_startY: 219,
              second_array: ["16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 241,
              am_y: 185,
              am_sc_path: '27.png',
              am_en_path: '27.png',
              pm_x: 241,
              pm_y: 185,
              pm_sc_path: '29.png',
              pm_en_path: '29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 321,
              y: 210,
              week_en: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_tc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_sc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 0,
              day_startY: 0,
              day_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '62.png',
              month_unit_tc: '62.png',
              month_unit_en: '62.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 321,
              year_startY: 185,
              year_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_zero: 1,
              year_space: 0,
              year_unit_sc: '61.png',
              year_unit_tc: '61.png',
              year_unit_en: '61.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 323,
              y: 236,
              image_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 104,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: true,
              h_space: 0,
              invalid_image: '103.png',
              dot_image: '104.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 134,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: true,
              h_space: 0,
              invalid_image: '105.png',
              dot_image: '106.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              invalid_image: '107.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              invalid_image: '108.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '110.png',
              unit_tc: '110.png',
              unit_en: '110.png',
              invalid_image: '109.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '112.png',
              unit_tc: '112.png',
              unit_en: '112.png',
              dot_image: '111.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              dot_image: '113.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 402,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 372,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              invalid_image: '114.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 372,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '116.png',
              unit_tc: '116.png',
              unit_en: '116.png',
              invalid_image: '115.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 444,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '119.png',
              unit_tc: '119.png',
              unit_en: '119.png',
              invalid_image: '118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 47,
              image_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 55,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '151.png',
              unit_tc: '151.png',
              unit_en: '151.png',
              negative_image: '150.png',
              invalid_image: '149.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 56,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '154.png',
              unit_tc: '154.png',
              unit_en: '154.png',
              negative_image: '153.png',
              invalid_image: '152.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 56,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '157.png',
              unit_tc: '157.png',
              unit_en: '157.png',
              negative_image: '156.png',
              invalid_image: '155.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 18,
              image_array: ["165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 14,
              font_array: ["175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png"],
              padding: false,
              h_space: 0,
              unit_sc: '185.png',
              unit_tc: '185.png',
              unit_en: '185.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 186,
              y: 10,
              src: '186.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 10,
              src: '187.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 160,
              y: 9,
              src: '188.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '189.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 184,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: '15.png',
              hour_unit_tc: '15.png',
              hour_unit_en: '15.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 174,
              minute_startY: 183,
              minute_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 292,
              y: 212,
              week_en: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_tc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              week_sc: ["30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 292,
              y: 236,
              image_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 0,
              day_startY: 0,
              day_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '62.png',
              month_unit_tc: '62.png',
              month_unit_en: '62.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 294,
              year_startY: 184,
              year_sc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_tc_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_en_array: ["51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png"],
              year_zero: 1,
              year_space: 0,
              year_unit_sc: '61.png',
              year_unit_tc: '61.png',
              year_unit_en: '61.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 104,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: true,
              h_space: 0,
              invalid_image: '103.png',
              dot_image: '104.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 134,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: true,
              h_space: 0,
              invalid_image: '105.png',
              dot_image: '106.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              invalid_image: '108.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '110.png',
              unit_tc: '110.png',
              unit_en: '110.png',
              invalid_image: '109.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 30,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '112.png',
              unit_tc: '112.png',
              unit_en: '112.png',
              dot_image: '111.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 215,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              dot_image: '113.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 402,
              y: 323,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 444,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '119.png',
              unit_tc: '119.png',
              unit_en: '119.png',
              invalid_image: '118.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 99,
              y: 47,
              image_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 55,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '151.png',
              unit_tc: '151.png',
              unit_en: '151.png',
              negative_image: '150.png',
              invalid_image: '149.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 56,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '154.png',
              unit_tc: '154.png',
              unit_en: '154.png',
              negative_image: '153.png',
              invalid_image: '152.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 56,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              unit_sc: '157.png',
              unit_tc: '157.png',
              unit_en: '157.png',
              negative_image: '156.png',
              invalid_image: '155.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 16,
              image_array: ["165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 13,
              font_array: ["175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png","184.png"],
              padding: false,
              h_space: 0,
              unit_sc: '185.png',
              unit_tc: '185.png',
              unit_en: '185.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 105,
              font_array: ["93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png"],
              padding: false,
              h_space: 0,
              invalid_image: '190.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 91,
              w: 170,
              h: 72,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 91,
              w: 84,
              h: 72,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 278,
              w: 102,
              h: 79,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 278,
              w: 102,
              h: 79,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 358,
              w: 144,
              h: 67,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 179,
              y: 358,
              w: 117,
              h: 68,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 113,
              y: 427,
              w: 247,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 40,
              w: 241,
              h: 49,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 15,
              y: 166,
              w: 200,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}